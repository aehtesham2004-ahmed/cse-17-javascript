# Odin Recipes

This is my first project from The Odin Project.

Skills demonstrated:
- HTML Boilerplate
- Headings and Paragraphs
- Links and Navigation
- Images
- Lists
- Git and GitHub
